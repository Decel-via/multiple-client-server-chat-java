package Main.client;

import Main.database.DatabaseManager;


public class WaitForMessage {

    private String tablename;

    public  WaitForMessage(String tablename){
        this.tablename = tablename;
        checkActivity(tablename);
    }
    private void checkActivity(String tablename) {
        Thread activityThread = new Thread(() -> {


            while (true) {
                try {
                    DatabaseManager.outputMessageInTable(tablename); // send all messages to GUI the clears them

                    Thread.sleep(5 * 1 * 1000); // Sleep for 5 seconds
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        activityThread.start();
    }
}
