package Main.client;

import Main.GUI.ClientLogin;

public class Client {



    public static void main(String[] args) {
        ClientLogin clientLogin = new ClientLogin();


    }
}
