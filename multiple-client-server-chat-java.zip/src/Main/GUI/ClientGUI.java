package Main.GUI;

import Main.client.WaitForMessage;
import Main.database.DatabaseManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class ClientGUI extends JFrame {

    private static JTextArea outputTextArea;
    private JTextField inputTextField;
    private JButton sendButton;
    private JScrollPane scrollPane;
    private JButton updatelistButton;

    private Socket socket;
    private PrintWriter cout;
    private String name;

    public ClientGUI(String IPaddress, String port, String name, UUID ID) {
        //title
        super(name.concat(" Chat"));

        // message board
        outputTextArea = new JTextArea();
        outputTextArea.setEditable(false);
        scrollPane = new JScrollPane(outputTextArea);
        add(scrollPane, BorderLayout.CENTER);

        // input box
        inputTextField = new JTextField();
        add(inputTextField, BorderLayout.SOUTH);

        // send box
        sendButton = new JButton("Send");
        updatelistButton  = new JButton("update local list");

        updatelistButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // if the client is a coordinator, then the coordinator status is transferred
                DatabaseManager.updateTable(name);
                appendToOutput("Current list: ");
                DatabaseManager.requestClientData(name);
            }
        });

        JPanel buttonPanel = new JPanel(new BorderLayout());
        buttonPanel.add(sendButton, BorderLayout.SOUTH);
        buttonPanel.add(updatelistButton, BorderLayout.NORTH);

        add(buttonPanel, BorderLayout.EAST);


        // add exit button
        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // if the client is a coordinator, then the coordinator status is transferred
                if(DatabaseManager.clientStatus(name).equals("Coordinator")){
                    DatabaseManager.updateRandomClientStatus("Coordinator");

                }
                System.exit(0);
            }
        });
        add(exitButton, BorderLayout.NORTH );

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setVisible(true);
        DatabaseManager.createMessageTable(name);
        WaitForMessage waitForMessage = new WaitForMessage(name);

        try {
            // creates a Socket
            socket = new Socket(IPaddress, Integer.parseInt(port));
            //captures output stream for the socket
            cout = new PrintWriter(socket.getOutputStream(), true);
            // creates Client thread
            //ThreadClient threadClient = new ThreadClient(socket, name);
            //new Thread(threadClient).start();
            // adds all clients info into Database manager
            DatabaseManager.addClient(name, ID, "Client", String.valueOf(socket.getLocalAddress()), socket.getLocalPort());
            DatabaseManager.createClientTable(name);
            DatabaseManager.createMessageTable(name);
            DatabaseManager.getClientInfoRowCount();
            appendToOutput("you have entered the chat");

            // if a client is the first person in the database
            if (DatabaseManager.rowCount == 1) {
                appendToOutput("SERVER: You are the first member in this server");
                // client becomes coordinator
                DatabaseManager.applyCoordinator(name);
                //appendToOutput("SERVER: Your are coordinator");

                DatabaseManager.updateTable(name);
            } else {
                // client gets their own local list
                DatabaseManager.requestClientData(name);
            }

            cout.println(name + ": has joined chat-room. type /updatelist to add to list of current members");

            sendButton.addActionListener(new ActionListener() {
                // LIST OF COMMANDS
                @Override
                public void actionPerformed(ActionEvent e) {
                    String message = (name + ": ");
                    String reply = inputTextField.getText();
                    if (reply.equals("/logout")) {
                        if(DatabaseManager.clientStatus(name).equals("Coordinator")){
                            DatabaseManager.updateRandomClientStatus("Coordinator");
                        }
                        cout.println("/logout");
                        System.exit(0);


                    } else if (reply.startsWith("/whisper")) {
                        cout.println(reply);
                        appendToOutput(reply);
                    } else if (reply.startsWith("/remove")) {
                        if (DatabaseManager.clientStatus(name).equals("Coordinator")) {
                            cout.println(reply);
                            appendToOutput(reply);
                        } else {
                            appendToOutput("cannot perform this action as you are not a Coordinator");
                        }
                    } else if (reply.equals("/requestinfo")) {
                        appendToOutput("Current list: ");
                        DatabaseManager.requestClientData(name);
                    } else if (reply.equals("/check")) {
                        if (DatabaseManager.clientStatus(name).equals("Coordinator")) {
                            HashMap<String, String> tableStatus = DatabaseManager.checkTableStatus();
                            ArrayList<String> inactiveMembers = new ArrayList<>();
                            tableStatus.forEach((key, value) -> appendToOutput(key + ": " + value));


                            for (String members : tableStatus.keySet()) {
                                if (tableStatus.get(members).equals("Inactive")) {
                                    cout.println(members + " is Inactive");
                                    inactiveMembers.add(members);
                                }
                            }
                            if (inactiveMembers.size() >= 1) {
                                cout.println("Remember to update your local lists. (to do this type /updatelist)");
                                appendToOutput("Remember to update your local lists. (to do this type /updatelist)");
                            }
                        } else {
                            appendToOutput("Cannot reform this action as you are not a Coordinator");
                        }
                    } else {
                        // else the message
                        LocalTime currentTime = LocalTime.now();
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
                        String formattedTime = currentTime.format(formatter);

                        cout.println(message + reply);
                        appendToOutput("[" +formattedTime+"] " + message + reply);
                    }

                }
            });
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
    public static void appendToOutput(String output) {
        // puts message in GUI
        outputTextArea.append(output + "\n");
    }

}

