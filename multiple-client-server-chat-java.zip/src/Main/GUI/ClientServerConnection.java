package Main.GUI;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.UUID;

import javax.swing.*;

public class ClientServerConnection extends JFrame {

    private JTextField idField, portField, ipField;
    private String name;

    public ClientServerConnection(String name) {
        this.name = name;
        // title
        setTitle("Server login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(300, 200));

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new FlowLayout());

        // GUI object

        JLabel idLabel = new JLabel("ID:");
        idField = new JTextField(20);
        idField.setEditable(false);
        mainPanel.add(idLabel);
        mainPanel.add(idField);

        JLabel portLabel = new JLabel("Server Port:");
        portField = new JTextField(20);
        mainPanel.add(portLabel);
        mainPanel.add(portField);

        JLabel ipLabel = new JLabel("Server IP:");
        ipField = new JTextField(20);
        mainPanel.add(ipLabel);
        mainPanel.add(ipField);

        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the current window
                System.exit(0); // End the program
            }
        });
        mainPanel.add(exitButton); // Add the button to the panel


        JButton enterButton = new JButton("Enter");
        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String id = idField.getText();
                String port = portField.getText();
                // ensures the port is correct
                if (port.isEmpty()) {
                    JOptionPane.showMessageDialog(ClientServerConnection.this, "Port cannot be empty.");
                    return;
                } else if (!port.equals("8080")) {
                    JOptionPane.showMessageDialog(ClientServerConnection.this, "Cannot connect to Server please check if Server port is correct");
                    return;
                }
                String ip = ipField.getText();
                // ensures the IP is correct
                if (ip.isEmpty()) {
                    JOptionPane.showMessageDialog(ClientServerConnection.this, "IP address cannot be empty.");
                    return;
                } else if (!ip.equals("127.0.0.1")) {
                    JOptionPane.showMessageDialog(ClientServerConnection.this, "Cannot connect to Server please check if IP address is correct");
                    return;
                }
                dispose();
                new ClientGUI(ip, port, name, UUID.fromString(id));
            }
        });
        mainPanel.add(enterButton);

        add(mainPanel);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);

        idField.setText(UUID.randomUUID().toString());
    }

}