package Main.GUI;

import Main.database.DatabaseManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ClientLogin extends JFrame {

    private JTextField nameField;
    private JLabel nameLabel;
    private JButton loginButton;
    private JButton exitButton;

    public ClientLogin() {
        //title
        super("Client Login");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(3, 1));

        //gui objects
        nameLabel = new JLabel("Please enter your name:");
        nameField = new JTextField();
        loginButton = new JButton("Log in");
        exitButton = new JButton("Exit");

        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(loginButton);
        panel.add(exitButton);

        getContentPane().add(panel);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();

                // if user doesn't enter a name
                if (name.isEmpty()) {
                    JOptionPane.showMessageDialog(ClientLogin.this, "Name cannot be empty.");
                    return;
                }
                // if the name does exist in the db then user cant enter it
                if (DatabaseManager.doesNameExist(name)) {
                    JOptionPane.showMessageDialog(ClientLogin.this, "That name already exists. Please enter a different name.");
                    return;
                }
                // create next page
                new ClientServerConnection(name);
                // dispose of this page
                dispose();
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // ends program
                System.exit(0);
            }
        });


    }
}

