package Main.GUI;

import Main.database.DatabaseManager;
import Main.server.Server;

import javax.swing.*;
import java.awt.*;

import java.io.OutputStream;
import java.io.PrintStream;

public class ServerGUI extends JFrame {

    private JTextArea outputArea;
    private JList<String> clientList;
    public static DefaultListModel<String> clientListModel;

    public ServerGUI() {
        // title
        setTitle("Server Terminal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // create JTextArea to display output
        // create JLabel to display "Server:"
        JLabel serverLabel = new JLabel("Server:");


        outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setBackground(Color.BLACK);
        outputArea.setForeground(Color.GREEN);

        // redirect System.out to the JTextArea
        System.setOut(new PrintStream(new TextAreaOutputStream(outputArea)));

        JScrollPane outputScrollPane = new JScrollPane(outputArea);
        outputScrollPane.setColumnHeaderView(serverLabel);


        // create JList to display clientNameList
        clientListModel = new DefaultListModel<>();
        clientList = new JList<>(clientListModel);

        JScrollPane clientScrollPane = new JScrollPane();
        JPanel clientPanel = new JPanel();
        clientListModel = new DefaultListModel<>();
        clientList = new JList<>(clientListModel);
        clientList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        clientList.setEnabled(false);
        clientList.setBackground(Color.DARK_GRAY);
        clientList.setForeground(Color.WHITE);
        clientPanel = new JPanel(new BorderLayout());
        clientPanel.setBackground(Color.DARK_GRAY);
        JLabel clientLabel = new JLabel("Current members:");
        clientLabel.setForeground(Color.WHITE);
        clientPanel.add(clientLabel, BorderLayout.NORTH);
        clientScrollPane = new JScrollPane(clientList);
        clientScrollPane.getViewport().setBackground(Color.DARK_GRAY);
        clientPanel.add(clientScrollPane, BorderLayout.CENTER);

        JLabel currentMembersLabel = new JLabel("Current members:");
        clientScrollPane.setColumnHeaderView(currentMembersLabel);


        // add output and client lists to split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                outputScrollPane, clientScrollPane);
        splitPane.setResizeWeight(1.0);

        getContentPane().add(splitPane);

        // add exit button
        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(e -> System.exit(0));
        add(exitButton, BorderLayout.SOUTH);

        setSize(800, 600);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void updateClientList() {
        // updates client list in the GUI
        clientListModel.clear();
        for (String clientName : DatabaseManager.getAllClientNames()) {
            if (DatabaseManager.clientStatus(clientName).equals("Coordinator")) {
                clientListModel.addElement(clientName +"(Coordinator)");
            }else {
                clientListModel.addElement(clientName);
            }
        }
    }

    private static class TextAreaOutputStream extends OutputStream {
        // The class redirects all System.out.println statements to the GUI

        private final JTextArea textArea;

        public TextAreaOutputStream(JTextArea textArea) {
            this.textArea = textArea;
        }

        @Override
        public void write(int b) {
            textArea.append(String.valueOf((char) b));
            textArea.setCaretPosition(textArea.getDocument().getLength());
        }
    }
}


