

import Main.client.Client;
import Main.database.DatabaseManager;
import org.junit.jupiter.api.Test;

import javax.xml.namespace.QName;

import java.net.Socket;
import java.sql.SQLException;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class ClientTest {


    @Test
    public void testClientCreation() {
        Client client = new Client();
        assertNotNull(client);
    }

    @Test
    public void testDatabaseManagerNameExist() {
        boolean result = DatabaseManager.doesNameExist("Andrei");
        assertTrue(result);
    }

    @Test
     public void firstMemberCheck() throws SQLException {
        DatabaseManager.createTables();
        UUID ID = UUID.randomUUID();
        String name  = "Andrei";
        String socket = "127.0.0.1";
        int port = 58533;

        DatabaseManager.addClient(name, ID, "Client", socket, port);
        DatabaseManager.getClientInfoRowCount();
        int result = DatabaseManager.rowCount;
        assertEquals(1,result);
    }

}