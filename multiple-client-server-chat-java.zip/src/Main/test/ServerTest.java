import Main.server.Server;
import Main.server.MessageThread;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Modifier;



import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;

class ServerTest {
    @Test
    void testGetServer() {
        Server s1 = Server.getServer();
        Server s2 = Server.getServer();
        assertSame(s1, s2);
    }


    @Test
    void testStartServer() throws InterruptedException {
        Thread t = new Thread(() -> Server.getServer().startServer());
        t.start();
        Thread.sleep(1000); // wait for server to start
        assertTrue(t.isAlive());
        t.interrupt(); // interrupt the server thread
        t.join(1000); // wait for the server thread to terminate

    }
    @Test
    public void testThreadServer() {
        Socket socket = new Socket();
        ArrayList<Socket> clients = new ArrayList<>();
        HashMap<Socket, String> clientNameList = new HashMap<>();
        MessageThread threadServer = new MessageThread(socket, clients, clientNameList);
        assertNotNull(threadServer);
    }
}