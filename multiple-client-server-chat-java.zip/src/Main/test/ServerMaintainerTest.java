import Main.server.ServerMaintainer;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ServerMaintainerTest {

    @Test
    public void testServerMaintainer() {
        ServerMaintainer serverMaintainer = new ServerMaintainer();
        assertNotNull(serverMaintainer);
    }
}