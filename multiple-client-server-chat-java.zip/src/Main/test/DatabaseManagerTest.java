import Main.database.DatabaseManager;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.swing.*;

import static org.junit.jupiter.api.Assertions.*;
import java.sql.*;
import java.util.HashMap;
import java.util.UUID;

public class DatabaseManagerTest {
    private static Connection connection;

    @BeforeEach
    void createDatabase(){
        DatabaseManager databaseManager = new DatabaseManager();
        UUID ID = UUID.randomUUID();
        DatabaseManager.addClient("Alice",ID , "Inactive", "127.0.0.1", 8080);

    }
    @Test
    void testApplyCoordinator() throws SQLException {
        DatabaseManager.createMessageTable("Alice");
        DatabaseManager.applyCoordinator("Alice");
        String status = DatabaseManager.clientStatus("Alice");
        assertEquals("Coordinator", status);
    }

    @Test
    void createMessageTable(){
    DatabaseManager.createMessageTable("matt");
    assertTrue(true);
}
    @Test
    void rowcCountTrue(){
        DatabaseManager.getClientInfoRowCount();
        Integer num = DatabaseManager.rowCount;
        assertEquals(num, 1);
    }

    @Test
    void checkTableStatusTest() {
        DatabaseManager.createClientTable("Alice");
        HashMap<String, String> clientStatus = DatabaseManager.checkTableStatus();
        for(String name : clientStatus.keySet()) {
            assertEquals(name, "Alice");
        }
        for(String status : clientStatus.keySet()) {
            assertEquals(clientStatus.get(status), "Active");
        }


    }
}
