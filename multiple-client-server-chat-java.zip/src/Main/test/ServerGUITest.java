import Main.GUI.ServerGUI;
import Main.database.DatabaseManager;
import org.junit.jupiter.api.Test;

import javax.swing.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

public class ServerGUITest {

    @Test
    void testUpdateClientList() {
        // create a new instance of ServerGUI
        ServerGUI serverGUI = new ServerGUI();
        DatabaseManager databaseManager = new DatabaseManager();


        // add some test clients to the client list
        UUID ID = UUID.randomUUID();

        DatabaseManager.addClient("Alice",ID , "Inactive", "127.0.0.1", 8080);



        // call updateClientList to update the client list in the GUI
        serverGUI.updateClientList();

        // check that the client list contains the expected clients
        assertTrue(serverGUI.clientListModel.contains("Alice"));


        // remove the test clients from the client list
        DatabaseManager.removeClient("Alice");

}
}