package Main.database;

import Main.server.Server;

import java.sql.*;
import java.util.*;

import static Main.GUI.ClientGUI.appendToOutput;


public class DatabaseManager {
    private static Connection connection;
    public static int rowCount = 0;



    public DatabaseManager()  {
        try {

        createTables();
        }catch (SQLException e) {
            throw new RuntimeException("Cannot connect to database", e);
        }
    }

    public static void createTables() throws SQLException {
        connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
        Statement statement = connection.createStatement();

        String sql = "DROP TABLE IF EXISTS client_info";
        statement.executeUpdate(sql);

        // Create the client info table
         sql = "CREATE TABLE IF NOT EXISTS client_info ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "name TEXT NOT NULL,"
                + "client_id TEXT NOT NULL UNIQUE,"
                + "client_status TEXT NOT NULL," +
                 "ip_address TEXT NOT NULL," +
                 "port INTEGER," +
                 "activity TEXT" +
                ");";
        statement.executeUpdate(sql);

        System.out.println("DATABASE CONNECTED");

        statement.close();
    }
    public static void applyCoordinator(String name) {
        try {
            // gives a user the Coordinator status
            connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            PreparedStatement statement = connection.prepareStatement("UPDATE client_info " +
                    "SET client_status = 'Coordinator'" +
                    " WHERE name = ?");
            statement.setString(1, name);
            statement.executeUpdate();
            statement.close();
            addMessageInTable(name, "SERVER: You are Coordinator");


        } catch (SQLException e) {
            throw new RuntimeException("Cannot connect to database", e);
        }}

    public static void getClientInfoRowCount() {
        // updates the number of clients active
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            Statement count = connection.createStatement();
            ResultSet rs = count.executeQuery("SELECT COUNT(name) FROM client_info");
            rowCount = rs.getInt(1);
            count.close();
        } catch (SQLException e) {
        throw new RuntimeException("Cannot connect to database", e);
    }}
    public static boolean doesNameExist(String name) {
        //checks if names exist in client_info
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
             PreparedStatement statement = connection.prepareStatement("SELECT name FROM client_info WHERE name = ?");
        ) {
            statement.setString(1, name);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Cannot connect to database", e);
        }
    }
    public static HashMap checkTableStatus() {
        HashMap<String, String> clientStatus;
        List<String> names = new ArrayList<>();
        //puts all names into a list
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT name FROM client_info");
            while (rs.next()) {
                names.add(rs.getString("name"));
            }
            statement.close();

        } catch (SQLException e) {
            throw new RuntimeException("Cannot connect to database", e);
        }
        try {
            // Get the ID values from the client_info table
            clientStatus = new HashMap<>();
            for (String name : names) {
                List<UUID> clientInfoIDs = new ArrayList<>();
                Connection conn = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
                PreparedStatement stmt = conn.prepareStatement("SELECT client_id FROM client_info");
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    clientInfoIDs.add(UUID.fromString(rs.getString("client_id")));
                }
                stmt.close();
                conn.close();

                // Get the ID values from the user-inputted table
                List<UUID> tableIDs = new ArrayList<>();
                conn = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
                stmt = conn.prepareStatement("SELECT client_id FROM " + name);
                rs = stmt.executeQuery();
                while (rs.next()) {
                    tableIDs.add(UUID.fromString(rs.getString("client_id")));
                }
                stmt.close();
                conn.close();

                // Check if the lists match and return the appropriate status
                Collections.sort(clientInfoIDs);
                Collections.sort(tableIDs);
                if (clientInfoIDs.equals(tableIDs)) {
                    clientStatus.put(name, "Active");
                    connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
                    PreparedStatement statement = connection.prepareStatement("UPDATE client_info " +
                            "SET activity = 'Active'" +
                            " WHERE name = ?");
                    statement.setString(1, name);
                    statement.executeUpdate();
                    statement.close();
                } else {
                    clientStatus.put(name, "Inactive");
                    connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
                    PreparedStatement statement = connection.prepareStatement("UPDATE client_info " +
                            "SET activity = 'Inactive'" +
                            " WHERE name = ?");
                    statement.setString(1, name);
                    statement.executeUpdate();
                    statement.close();

                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Cannot connect to database", e);
        }
        return clientStatus;
    }
    public static List<String> getAllClientNames() {
        // returns a list of members currently active
        List<String> names = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
             PreparedStatement statement = connection.prepareStatement("SELECT name FROM client_info");
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                String name = rs.getString("name");
                names.add(name);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Cannot connect to database", e);
        }
        return names;
    }
    public static void updateRandomClientStatus(String newStatus) {
        try {
            // takes the information of the coordinator
            Connection connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM client_info WHERE client_status = ?");
            statement.setString(1, "Coordinator");
            ResultSet rs = statement.executeQuery();
            String name = null;
            UUID clientID = null;
            String ipAddress = null;
            int port = 0;
            if (rs.next()) {
                int id = rs.getInt("id");
                name = rs.getString("name");
                clientID = UUID.fromString(rs.getString("client_id"));
                String clientStatus = rs.getString("client_status");
                ipAddress = rs.getString("ip_address");
                port = rs.getInt("port");
                // do something with the variables
            }
            statement.close();
            // remove coordinator
            removeClient(name);
            // give someone else coordinator
            PreparedStatement statement2 = connection.prepareStatement("UPDATE client_info SET client_status = ? WHERE id = (SELECT id FROM client_info ORDER BY RANDOM() LIMIT 1)");
            statement2.setString(1, newStatus);
            statement2.executeUpdate();
            statement2.close();
            // add previous coordinator back as a client
            addClient(name, clientID, "Client", ipAddress, port);
            statement.close();
            // takes name of new client
            String coName = null;
            PreparedStatement statement3 = connection.prepareStatement("SELECT name " + "FROM client_info" + " WHERE client_status = 'Coordinator' ");
            ResultSet rs2 = statement3.executeQuery();
            if (rs2.next()) {
                coName = rs2.getString("name");
                Server.serverMessage(coName + " is the new Coordinator");
            }
            statement3.close();

            if (coName != null) {
                addMessageInTable(coName, " You are Coordinator");
            }
            // updates everyone's tables
            List<String> clients = getAllClientNames();
            for (String client : clients){
                if (!client.equals(name)) {
                    updateTable(client);
                }
                addMessageInTable(client, coName + " is the coordinator");}
        } catch (SQLException e) {
            throw new RuntimeException("Cannot connect to database", e);
        }
    }
    public static void removeClient(String name) {
        // removes a client from client_info
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            PreparedStatement remove = connection.prepareStatement("DELETE FROM client_info WHERE name = ?");
            remove.setString(1, name);
            remove.executeUpdate();
            remove.close();
        } catch (SQLException e) {
            throw new RuntimeException("Cannot connect to database", e);
        }
    }
    public static String clientStatus(String name) {
        // returns the status of a client
        String clientStat = null;
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
             PreparedStatement statement = connection.prepareStatement("SELECT client_status " + "FROM client_info" + " WHERE name = ?");
        ) {
            statement.setString(1, name);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    clientStat = rs.getString("client_status");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Cannot connect to database", e);
        }
        return clientStat;
    }

    public static void addClient(String name, UUID clientId, String status, String IP, Integer port) {
        // add a client into client info
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            String sql = "INSERT INTO client_info (name, client_id ,client_status,ip_address,port,activity) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setString(2, String.valueOf(clientId));
            statement.setString(3, status);
            statement.setString(4, String.valueOf(IP));
            statement.setInt(5, port);
            statement.setString(6, "Active");
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Cannot connect to database", e);
        }}
    public static void createClientTable(String tableName) {
        // creates a local list for a client
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            Statement statement = connection.createStatement();
            String sql = "DROP TABLE IF EXISTS " + tableName;
            statement.executeUpdate(sql);
            statement.executeUpdate("CREATE TABLE " + tableName + " AS SELECT * FROM client_info WHERE 1=0;");
            statement.executeUpdate("INSERT INTO " + tableName + " SELECT * FROM client_info;");
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Cannot connect to database", e);
        }
    }
    public static void updateTable(String tableName) {
        //  updates local list
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            PreparedStatement statement = connection.prepareStatement("DROP TABLE IF EXISTS " + tableName);
            statement.executeUpdate();
            statement.close();

            statement = connection.prepareStatement("CREATE TABLE IF NOT EXISTS " + tableName + " AS SELECT * FROM client_info");
            statement.executeUpdate();
            statement.close();



        } catch (SQLException e) {
            throw new RuntimeException("Cannot connect to database", e);
        }
    }
    public static void deleteTable(String tableName) {
        // delete local list
        try {
            Connection connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            Statement statement = connection.createStatement();
            statement.executeUpdate("DROP TABLE IF EXISTS " + tableName);
            statement.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException("Cannot connect to database", e);
        }
    }

    public static void requestClientData(String tableName) {
        // create local list in a gui
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            Statement count = connection.createStatement();
            ResultSet rs = count.executeQuery("SELECT name, client_id, client_status, ip_address, port, activity FROM " + tableName);
            appendToOutput("name" +  "\t" + "port" +  "\t" +
                    "client_status" +  "\t" + "ip_address" + "\t" + "Activity" +  "\t" + "client_id" );
            while(rs.next()) {
                appendToOutput(rs.getString("name") +  "\t" + rs.getString("port") +  "\t"
                        + rs.getString("client_status") +  "\t" + rs.getString("ip_address") +  "\t"
                         + rs.getString("activity")+   "\t" +rs.getString("client_id"));
            }
            count.close();
        } catch (SQLException e) {
            throw new RuntimeException("Cannot connect to database", e);
        }}

    public static void createMessageTable(String tableName) {
        // creates a message table
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            Statement statement = connection.createStatement();
            String truetableName = tableName.concat("messsages") ;
            String sql = "DROP TABLE IF EXISTS " + truetableName;
            statement.executeUpdate(sql);
            statement.close();
            connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS "+ truetableName+ " (" + "id INTEGER PRIMARY KEY AUTOINCREMENT" +
                    ", message TEXT);");
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Cannot connect to database", e);
        }
    }
    public static void addMessageInTable(String tableName, String message) {
        // adds a message table
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            String truetableName = tableName.concat("messsages") ;
            String sql = "INSERT INTO " + truetableName + " (message) VALUES (?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, message);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Cannot connect to database", e);
        }
    }
    public static void outputMessageInTable(String tableName) {
        // displays every message in table then clears table
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:src/sqlite/Client_Server.db");
            Statement statement = connection.createStatement();
            String truetableName = tableName.concat("messsages") ;
            ResultSet rs = statement.executeQuery("SELECT message FROM " + truetableName);
            while(rs.next()) {
                appendToOutput(rs.getString("message"));
            }
            statement.close();
            createMessageTable(tableName);

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Cannot connect to database", e);
        }
    }
    public void close() throws SQLException {
        // closes connections
        connection.close();
    }
}
