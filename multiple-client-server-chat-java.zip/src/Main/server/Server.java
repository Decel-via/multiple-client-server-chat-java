package Main.server;

import Main.GUI.ServerGUI;
import Main.database.DatabaseManager;


import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

public class Server {

    // Server is a Singleton
    private static Server server;
    private ArrayList<Socket> clients = new ArrayList<>();
    public static HashMap<Socket, String> clientNameList = new HashMap<>();

    private Server() {}

    public static Server getServer() {
        // ensures server is a singleton
        if (server == null) {
            server = new Server();
        }
        return server;
    }
    public static void serverMessage(String message){

        System.out.println( "SERVER: " + message);
        }

    public void startServer() {
        // server connects
        try (ServerSocket serversocket = new ServerSocket(8080)) {
            System.out.println("Server is started...");

            try {
                InetAddress ip = InetAddress.getByName("localhost");

                System.out.println("Host Name: " + ip.getHostName());
                System.out.println("IP Address: " + ip.getHostAddress());
                System.out.println("Server Port: 8080");
            } catch (Exception e){
                e.printStackTrace();
            }
            // Creates Database manager and server maintainer
            DatabaseManager databaseManager = new DatabaseManager();
            ServerMaintainer ServerMaintainer = new ServerMaintainer();

            while (true) {
                // whenever a client connects, socket is added to a list of clients and a server thread for the client
                // is connected and started
                Socket socket = serversocket.accept();
                clients.add(socket);
                MessageThread ThreadServer = new MessageThread(socket, clients, clientNameList);
                ThreadServer.start();

            }

        } catch (Exception e) {
            System.out.println(e.getStackTrace());
        }
    }
    public static void main(String[] args) {
        ServerGUI gui = new ServerGUI();
        Server.getServer().startServer();
    }
}