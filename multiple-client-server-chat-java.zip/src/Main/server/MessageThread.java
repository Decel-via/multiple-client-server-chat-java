package Main.server;

import Main.GUI.ServerGUI;
import Main.database.DatabaseManager;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.time.LocalTime;

/**
 * Thread for Server
 */
public class MessageThread extends Thread {

    private Socket socket;
    private ArrayList<Socket> clients;
    private HashMap<Socket, String> clientNameList;


    public MessageThread(Socket socket, ArrayList<Socket> clients, HashMap<Socket, String> clientNameList) {
        this.socket = socket;
        this.clients = clients;
        this.clientNameList = clientNameList;


    }

    @Override
    public void run() {
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            // waits for command of messages from clients
            while (true) {
                String outputString = input.readLine();
                // removes user
                if (outputString.equals("/logout")) {
                    throw new SocketException();
                }
                // separates string for /whisper command
                if (outputString.startsWith("/whisper")) {
                    String[] whisperArgs = outputString.split("\\s+", 3);
                    String recipient = whisperArgs[1];
                    String message = whisperArgs[2];
                    if (DatabaseManager.doesNameExist(recipient)) {
                    sendMessageToRecipient(recipient, message, socket);}
                    else {
                        DatabaseManager.addMessageInTable(clientNameList.get(socket), "Recipient does not exist");
                    }
                    // removes user
                } else if (outputString.startsWith("/remove ")) {
                    String[] removeArgs = outputString.split("\\s+", 2);
                    String removeName = removeArgs[1];
                    boolean removed = false;
                    for (Socket s : clientNameList.keySet()) {
                        if (clientNameList.get(s).equals(removeName)) {
                            PrintWriter pw = new PrintWriter(s.getOutputStream(), true);
                            DatabaseManager.addMessageInTable(removeName, "You have been removed");
                            s.close();
                            removed = true;
                            break;
                        }
                    }
                    //user does not exist
                    if (!removed) {
                        DatabaseManager.addMessageInTable(clientNameList.get(socket), "User " + removeName + " not found.");
                    }

                } else if (!clientNameList.containsKey(socket)) {
                    // when a client joins do this
                    String[] messageString = outputString.split(":", 2);
                    clientNameList.put(socket, messageString[0]);
                    ServerGUI.updateClientList();
                    showMessageToAllClients(socket, messageString[0] + messageString[1]);


                } else {
                    //System.out.println(outputString);
                    showMessageToAllClients(socket, outputString);
                }
            }
        } catch (SocketException e) {
            // do this when user leaves

            String printMessage = clientNameList.get(socket) + " left the chat room. type /updatelist to add to" +
                    " list of current memebers";
            if(DatabaseManager.clientStatus(clientNameList.get(socket)).equals("Coordinator")){
                DatabaseManager.updateRandomClientStatus("Coordinator");

            }
            DatabaseManager.removeClient(clientNameList.get(socket));
            DatabaseManager.deleteTable(clientNameList.get(socket));
            System.out.println(printMessage);
            showMessageToAllClients(socket, printMessage);
            Server.clientNameList.remove(socket);
            ServerGUI.updateClientList();
            clients.remove(socket);
            clientNameList.remove(socket);
        } catch (Exception e) {
            System.out.println(e.getStackTrace());
        }
    }

    private void sendMessageToRecipient(String recipientName, String message, Socket senderSocket) {
        // Send private messages
        LocalTime currentTime = LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        String formattedTime = currentTime.format(formatter);

        for (Socket recipientSocket : clientNameList.keySet()) {
            if (clientNameList.get(recipientSocket).equals(recipientName)) {
                try {
                    PrintWriter printWriter = new PrintWriter(recipientSocket.getOutputStream(), true);
                    String complete = ("[" +formattedTime+"]" + " (Private) " + clientNameList.get(senderSocket) + ": " + message);
                    DatabaseManager.addMessageInTable(recipientName, complete);
                    break;
                } catch (IOException ex) {
                    System.out.println(ex);
                }
            }
        }
    }

    private void showMessageToAllClients(Socket sender, String outputString) {
        // sends public messages
        LocalTime currentTime = LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        String formattedTime = currentTime.format(formatter);
        Socket socket;
        PrintWriter printWriter;

        int i = 0;
        while (i < clients.size()) {
            socket = clients.get(i);

            i++;
            try {
                if (socket != sender) {
                    printWriter = new PrintWriter(socket.getOutputStream(), true);
                    DatabaseManager.addMessageInTable(clientNameList.get(socket), "[" +formattedTime+"] " + outputString);
                }
            } catch (IOException ex) {
                System.out.println(ex);
            }
        }
    }




}
