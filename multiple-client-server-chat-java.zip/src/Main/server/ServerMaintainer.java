package Main.server;

import Main.GUI.ServerGUI;
import Main.database.DatabaseManager;

import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;

public class ServerMaintainer {

    public ServerMaintainer(){
        checkActivity();
    }

    private void checkActivity() {
        Thread activityThread = new Thread(() -> {
            // thread is started  and timer starts
            LocalTime startTime = LocalTime.now();

            while (true) {
                try {
                    // current time is created
                    LocalTime endTime = LocalTime.now();
                    ArrayList<String> inactiveMembers = new ArrayList<>();
                    // takes hashmap of all clients and there activity status
                    HashMap<String, String> tableStatus = DatabaseManager.checkTableStatus();
                    String coordinator = null;

                    // finds coordinator
                    for (String members : tableStatus.keySet()){
                        if(DatabaseManager.clientStatus(members).equals("Coordinator")){
                            coordinator = members;
                        }
                    }
                    // puts all inactive members in a list
                    for (String members : tableStatus.keySet()) {
                        if (tableStatus.get(members).equals("Inactive")) {
                            inactiveMembers.add(members);
                        }
                    }
                    // if there are inactive members
                    if (inactiveMembers.size() >= 1) {
                        // takes difference in time
                        long durationInMinutes = Duration.between(startTime, endTime).toMinutes();
                        // displays all inactive members  and the time at which they were in active
                        System.out.println("Inactive members: " + inactiveMembers + " at " + durationInMinutes + " min(s) since the server started");

                        // if inactive member is a coordinator
                        for (String members : inactiveMembers){
                            if(members.equals(coordinator)){
                                // changes coordinator status and updates GUI
                                DatabaseManager.updateRandomClientStatus("Coordinator");
                                ServerGUI.updateClientList();

                            }
                        }
                    }
                    if (tableStatus.size() >= 1 && coordinator == null){
                        // if no one is a coordinator the take someone at random and give them the status
                        String NewCoordinator = tableStatus.keySet().iterator().next();
                        DatabaseManager.applyCoordinator(NewCoordinator);
                        ServerGUI.updateClientList();
                    }

                    Thread.sleep(2 * 60 * 1000); // Sleep for 2 minutes
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        activityThread.start();
    }
}

